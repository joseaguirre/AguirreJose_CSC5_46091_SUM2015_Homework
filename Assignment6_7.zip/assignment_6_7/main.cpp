 /* 
 * File:   main.cpp
 * Author: Jose Aguirre
 * Created on July 23, 2015, 11:08 PM
 *Purpose:  Savitch 9th Edition Chapter 7 7 problems 
 */ 

//System Libraries
#include <iostream> //I/O Library
#include <cstdlib>//the absolute values
#include <cmath>//std dev
using namespace std; 
//User Libraries
//Global Constants
//Function Prototypes
//problem 1
void problemOne();
void firstLast2(int array[], int SIZE);
void problemTwo();
void countNum2(int array[], int SIZE);
void problemThree();
void swapFrontBack(int array[], int SIZE);
//problem4
void problemFour();
int length(char []);
bool digitAdd(char,char,char &,bool=false);
int sizeResult(char [],char []);
bool numberAdd(char [],char [],char []);
//problem five
void problemFive();
void introduction();
void input(char word[], int& size);
void delete_repeats(char word[], int& size); 
//problem six
void problemSix();
float stdDev(float [], int SIZE);
//Execution Begins Here!
int main()
{
    int choice;
    cout << "Choose problem #: "; 
    cin >> choice; 
   
    switch(choice)
    {
        case 1: problemOne();
        break;
        case 2: problemTwo(); 
        break;   
        case 3: problemThree();
        break;
        case 4: problemFour();
        break;
        case 5: problemFive();
        break; 
        case 6: problemSix();
        break; 
            }
    return 0;
}
void problemOne()
{
    /*Author: Jose Aguirre
     *Created on July 22, 2015, 7:25 AM
     *Class: C++
     *Purpose: Savitch 9th Edition Chapter 6 Practice Program #1
     * If function begins with 2 it returns T, else F
     */

    //declare variables
    const int SIZE=10;//declare and initialize size
    //declare and set elements to 1st array
    int array1[SIZE]={2,13,24,3,2,5,6,2,1,2};
    //declare and set elements to 2nd array
    int array2[SIZE]={23,3,2,3,3,7,8,2,0,2};
    //call the function 
    firstLast2(array2, SIZE);    
}
/**********************************************
 ****************** firstLast2 ****************
 **********************************************
 * Purpose: Checks to see if array begins w/ 2
 * 
 * input: if first element = 2 
 * output: -> T
 * input if first element != 2
 * output: -> F
 * *********************************************/
void firstLast2(int array[], int SIZE)
{
    //outputs the elements
    cout<<"The array elements are: "<<endl; 
    for(int i=0;i<SIZE;i++)
    {
        cout<<array[i]<<" ";
    }
    //return true if the function begins with 2
    if(array[0]==2)
        cout<<"\nTrue"<<endl;
    //else return false
     else
        cout<<"\nFalse"<<endl; 
}
void problemTwo()
{
   /*Author: Jose Aguirre
 *Created on July 22, 2015, 6:49 PM
 *Class: C++
 *Purpose: Savitch 9th Edition Chapter 7 Practice Program #2
 *Counts how many 2's are in array
*/


    //declare variables
    const int SIZE=10;//declare and initialize size
    //declare and set elements to 1st array
    int array1[SIZE]={2,13,24,3,2,5,6,2,1,2};
    //declare and set elements to 2nd array
    int array2[SIZE]={23,3,2,3,3,7,8,2,0,2};
    //call the function 
    countNum2(array1, SIZE);
}
/**********************************************
 ****************** countNum2 ****************
 **********************************************
 * Purpose: Checks to see how many 2's are elements
 * 
 * input: array, size
 * output: counts 2's->#of2's in array
 * *********************************************/
void countNum2(int array[], int SIZE)
{
    int count = 0; 
    //outputs the elements
    cout<<"The array elements are: "<<endl; 
    for(int i=0;i<SIZE;i++)
    {
        cout<<array[i]<<" ";
    }
   //counts how many elements are equal to two
    for(int i=0; i<SIZE;i++)
    {
        if(array[i]==2)
        count = count + 1; 
    }   
    cout<<"\nThere are this many 2's in your array: "<<count<<endl; 
}
void problemThree()
{
   /*Author: Jose Aguirre
 *Created on July 22, 2015, 6:55 PM
 *Class: C++
 *Purpose: Savitch 9th Edition Chapter 7 Practice Program #3
 *Swap Values
*/

    //declare variables
    const int SIZE0=0;//declare and initialize size 
    const int SIZE1=10;//declare and initialize size
    //declare and set elements to 0th array
    int array0[SIZE0]; 
    //declare and set elements to 1st array
    int array1[SIZE1]={5,13,24,3,2,5,6,2,1,7};
    //declare and set elements to 2nd array
    int array2[SIZE1]={23,3,2,3,3,7,8,2,0,6};
    //call the function 
    swapFrontBack(array2, SIZE1);
}
/**********************************************
 ******************swapFrontBack****************
 **********************************************
 * Purpose: Swaps first and last element
 * 
 * input: array, size
 * output: the array elements with first and last 
 * element swapped
 * *********************************************/
void swapFrontBack(int array[], int SIZE)
{
    //declare variables
    int temp;//for temporary swap
    if(SIZE==0)
    cout<<"There are no elements in the array."<<endl; 
    else if(SIZE>0)
    {
        //outputs the elements
        cout<<"The array elements are: "<<endl; 
        for(int i=0;i<SIZE;i++)
        {
            cout<<array[i]<<" ";
        }
        cout<<"\nIf you swap the first and last value"<<endl;
        cout<<"The array elements are now: "<<endl;  
            int temp; 
            int src=0; 
            int dest=SIZE-1; 
            temp=array[src];
            array[src]=array[dest]; 
            array[dest]=temp;
        for(int i=0;i<SIZE;i++)
        { 
            cout<<array[i]<<" ";
        }
    }   
}
void problemFour()
{
    /*Author: Jose Aguirre
 *Created on July 23, 2015, 10:21 AM
 *Class: C++
 *Purpose: Savitch 9th Edition Chapter 6 Programming Project #2
 * Adds Hex
*/
    //Create the test numbers using character arrays
    char number1[]="1BBCDABCDEF";
    char number2[]="F123ABCD451";
    char result[sizeResult(number1,number2)];
    //Add the numbers
    cout<<number1<<endl;
    cout<<number2<<endl;
    bool x=numberAdd(number1,number2,result);
    if(x)cout<<"addition overflow"<<endl;
    else cout<<result<<endl;   
}

/**********************************************
 ****************** numberAdd ****************
 **********************************************
 * Purpose: add the digits
 * 
 * input: two hex numbers
 * output: sum
 * *********************************************/
bool numberAdd(char n1[],char n2[],char r[])
{
    //Initialize the result array
    r[sizeResult(n1,n2)-1]='\0';
    for(int i=0;i<=sizeResult(n1,n2)-2;i++){
        r[i]='0';
    }
    //Start the counters
    int rcnt=sizeResult(n1,n2)-2;
    int n1cnt=length(n1)-1;
    int n2cnt=length(n2)-1;
    //Added the first digit
    bool c=digitAdd(n1[n1cnt--],n2[n2cnt--],r[rcnt--]);
    do{
    if(n1cnt<0&&n2cnt<0)return c;
    else if(n1cnt<0)c=digitAdd('0',n2[n2cnt--],r[rcnt--],c);
    else if(n2cnt<0)c=digitAdd(n1[n1cnt--],'0',r[rcnt--],c);
    else c=digitAdd(n1[n1cnt--],n2[n2cnt--],r[rcnt--],c);
    }while(true);
}
/**********************************************
 ******************sizeResult ****************
 **********************************************
 * Purpose: calls length function to measure 
 * elements
 * 
 * input: first and second numbers
 * output: size 1 is greater than size 2
 * returns the first size + 1
 * else size2+1
 * *********************************************/
int sizeResult(char n1[],char n2[]){
    int size1=length(n1);
    int size2=length(n2);
    if(size1>size2)return size1+1;
    return size2+1;
}
/**********************************************
 ****************** digitAdd ****************
 **********************************************
 * Purpose: convert digits from asci
 * 
 * input: inputs numbers to be added
 * output: returns sum/16 b/c 16=hex
 * *********************************************/
bool digitAdd(char n1,char n2,char &d,bool c){
    int i1=n1-48,i2=n2-48;
    if(n1>=65)i1=n1-55;
    if(n2>=65)i2=n2-55;
    int sum=i1+i2+c;
    if(sum%16>9){
        d=sum%16+55;
    }else{
        d=sum%16+48;
    }
    return sum/16;
}
/**********************************************
 ******************  length  ****************
 **********************************************
 * Purpose: counts the length of the digits
 * 
 * input: array -> counts the elements
 * output: returns elements in data set
 * *********************************************/
int length(char a[]){
    int cnt=0;
    do{}while(a[cnt++]!='\0');
    return cnt-1; 
}
void problemFive()
{
//variable declarations
    int counter, size, A;
    char array[81]={'j','o','s','e','a','g','u','i','r','r','e'};
    //prompt user input
    cout<<"This program tests to see if there are duplicate"<<endl
        <<"characters in your string."<<endl; 
    cout<<"Enter a string of characters: "<<endl; 
    input(array,size);
    delete_repeats(array,size);
    cout << "resulting array: ";
    for( int i = 0; i < size; i++ ) {
        cout << array[i] << " ";
    }
    cout << endl;
}

/**********************************************
 ******************    input   ****************
 **********************************************
 * Purpose: user inputs a string of characters
 * 
 * input: characters(hopefully some repeated)
 * output: counter
 * *********************************************/
void input(char word[], int& size)
{
    int counter = 0;
    cout << endl;
    cout << "counter = " << counter; // for testing purposes
    cout << endl;
    do
    {
        //counter++;  increment after storing the char (see below)
        cin.get(word[counter]); 
        cout << endl;
        cout << "counter = " << counter; // for testing purposes
        cout << ";  word[" << counter << "] = " << (int)word[counter];
        cout << endl;
        counter++; // moved increment here
    }while (word[counter-1] != '\n');
    size = counter - 1;
    cout << endl;
    cout << endl;
    cout << "counter = " << counter; // for testing purposes
    cout << endl;
}
/**********************************************
 ****************delete_repeats****************
 **********************************************
 * Purpose: delete duplicate characters
 * 
 * input: user inputs strings of characters
 * output: characters, but no duplicates
 * *********************************************/
void delete_repeats(char word[], int& size)
{
    int counter = 0;
    for (int i = 0; i < size; i++)
    {
        for (int j = i+1; j < size; j++)  // don't start j at 0; start AFTER i
        {
            if (word[i] == word[j])
            {
                for (int k = j; k < size - 1; k++) // don't go past end of array
                {
                    word[k]= word[k + 1];
                }
              j--;
              size--;
        	} 
        }
    }
}



void problemSix()
{
    //declare variables
    const int SIZE=10.0;
    float avg; 
    float a[SIZE]={1.9,2,3.5,4.2,5.3,6.4,6.3,7,8,2};
    avg=stdDev(a,SIZE);
    cout<<avg; 
}

float stdDev(float a[], int SIZE)
{
    float sum = 0.0; 
    float avg; 
    float numerator=0; 
    float stdDev; 
    for(int i=0;i<SIZE;i++)
    sum = sum + a[i];
    avg= sum/SIZE; 
    for(int i=0;i<SIZE;i++)
    numerator=numerator+((a[i]-avg)*(a[i]-avg));
    //calculate standard deviation
    stdDev=sqrt(numerator/SIZE);
    return stdDev; 
}

